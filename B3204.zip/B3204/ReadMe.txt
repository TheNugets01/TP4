Nous avons fais different choix de realisation

- Nous n'avons exploiter que les HttpCode 200 et 304
- Nous n'exploitons uniquement les requetes dont le referer n'est pas null
- Nous avons utiliser uniquement les requetes venant du sereur http://intranet-if.insa-lyon.fr pour effectuer le graph