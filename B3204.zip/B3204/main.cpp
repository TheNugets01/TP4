#include "TraiterLog.h"
#include <iostream>

int main(int nbArg, char *listArg [])
{  
    Analog( TraiterArgs(nbArg, listArg) );
    return 0;
}